<?php
    if($_GET){
        if(isset($_GET['id'])){
            require_once '../classes/Recibo.class.php';
            $recibo = new Recibo();
            $recibo->deleteRecibo($_GET['id']);
        }
    }
    header('Location: ../view/index.php');
?>

