<?php 
    require_once '../includes/Config.inc.php'; 
    setTitulo('Recibo - Listando o recibo');
    require_once '../includes/Header.inc.php';  
    require_once '../includes/Nav.inc.php'; 
?>
    
    <?php
        if($_GET){
            if(isset($_GET['id'])){
            require_once '../controller/recibo-listar.php';
            $lista_de_recibo = listarUm($_GET['id']);
            
            while($recibo = $lista_de_recibo->fetch(PDO::FETCH_ASSOC)){ 
                    $lista_de_placa = listarUmPlaca($recibo['id_placa']);
                    while($placa = $lista_de_placa->fetch(PDO::FETCH_ASSOC)){
                        $lista_de_cliente = listarUmCliente($placa['id_cliente']);
                        while($cliente = $lista_de_cliente->fetch(PDO::FETCH_ASSOC)){
                            if($placa['id_cliente'] == $cliente['id']){
                                echo '<p><b> Nome do Cliente: </b>'.$cliente['nome'].'</p>';
                            }
                        }
                    }
                    echo '<hr>';
                    echo '<h4 class="w3-center">Simulação da placa</h4>';
                    $lista_de_placa = listarUmPlaca($recibo['id_placa']);
                    while($placa = $lista_de_placa->fetch(PDO::FETCH_ASSOC)){
                        $cor_fundo = '';
                        $cor_texto = '';
                        if($placa['cor_fundo'] == 'branca'){
                            $cor_fundo = 'w3-wite';
                        }
                        else if($placa['cor_fundo'] == 'cinza'){
                            $cor_fundo = 'w3-gray';
                        }

                        if($placa['cor_texto'] == 'azul'){
                            $cor_texto = 'w3-text-blue';
                        }
                        else if($placa['cor_texto'] == 'amarelo'){
                            $cor_texto = 'w3-text-yellow';
                        }
                        else if($placa['cor_texto'] == 'vermelho'){
                            $cor_texto = 'w3-text-red';
                        }
                        else if($placa['cor_texto'] == 'verde'){
                            $cor_texto = 'w3-text-green';
                        }
                        else if($placa['cor_texto'] == 'preto'){
                            $cor_texto = 'w3-text-black';
                        }

                        echo '<div class="w3-container w3-panel w3-card '.$cor_fundo.'">';
                            echo '<p class="w3-center '.$cor_texto.'">'.$placa['frase'].'</p>';
                        echo '</div>';   
                        echo '<p><b>Largura: </b>'.$placa['largura'].'</p>';
                        echo '<p><b>Altura: </b>'.$placa['altura'].'</p>';
                    }             
                    echo '<p><b>Valor da Placa: </b>'.$recibo['valor_placa'].' R$</p>'; 
                    $desconto = ($recibo['valor_sinal'] * $recibo['valor_placa']);
                    echo '<p><b>Valor com desconto: </b>'.$desconto.' R$</p>';       
                    echo '</hr>';

                    echo '<a class="w3-btn w3-block w3-green" href="../controller/recibo-apagar.php?id='.$recibo['id'].'">Pago</a>';
            }
            }
        }
    ?>

<?php require_once '../includes/Footer.inc.php'; ?>