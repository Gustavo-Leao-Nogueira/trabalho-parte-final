<?php 
    require_once '../includes/Config.inc.php'; 
    setTitulo('Início');
    require_once '../includes/Header.inc.php';  
    require_once '../includes/Nav.inc.php'; 
?>
    

    <h3 class="w3-center">Seja bem vindo!</h3>
    <p>Cadastre o cliente, a placa e veja o recibo!</p>

    <?php require_once '../includes/Footer.inc.php'; ?>