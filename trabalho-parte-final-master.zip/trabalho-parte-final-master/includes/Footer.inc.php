</section>
    </main>

<footer class="w3-container w3-center w3-blue">
  <p>Criado pelos alunos de ADS da faculdade Senac-RS. </p>
</footer>

       
    </body>
</html>