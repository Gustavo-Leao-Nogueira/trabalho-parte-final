<?php 

function mensagem($titulo='', $mensagem=''){
    echo "<p><b>$titulo</b> $mensagem</p>";
}

?>