<?php 
    $titulo = "";  
    
    function setTitulo($titulo_aux){ 
        global $titulo;
        $titulo = $titulo_aux; 
    }
?>